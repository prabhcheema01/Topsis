# -*- coding: utf-8 -*-
"""
Created on Sun Jan 19 22:15:41 2020

@author: manjot
"""

usage :
    python myown.py data.csv "1,2,1,2" "+,+,-,+"